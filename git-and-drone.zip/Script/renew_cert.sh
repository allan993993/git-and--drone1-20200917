#!/bin/bash

#APP_ROOT="$1"
#ACME_DIR="$2"
ACME_DIR="~/.acme.sh"
DOCKER_ROOT="/opt"

SCRIPT_DIR=$(cd "$(dirname "$0")";pwd)
CERT_DOMAIN_LIST="$SCRIPT_DIR/domain_list"
APP_ROOT="$DOCKER_ROOT/nginx/html/web"
CERT_DIR="$DOCKER_ROOT/certs"
DOWNLOAD_DIR="$APP_ROOT/download/"
GITEA_CERT_DIR="/opt/gitea/gitea"
FILE_OWNER="devse"
CERT_FILE="ca.cer"
CERT_PFX_FILE="certificate.pfx"
RELOAD_FLAG="$SCRIPT_DIR/reload_nginx_flag"

# cron renew cert
cd $ACME_DIR/
# for force renew
#~/.acme.sh/acme.sh --cron --home --force $ACME_DIR/
# normal renew
~/.acme.sh/acme.sh --cron --home $ACME_DIR/

while read DOMAIN_NAME; do
	if [ -f $ACME_DIR/$DOMAIN_NAME/$CERT_FILE ]; then
		#timestamp=`date +%s`
		acme_cert_timestamp=`stat -c %Y $ACME_DIR/$DOMAIN_NAME/$CERT_FILE`
		sys_pfx_timestamp=`stat -c %Y $CERT_DIR/$DOMAIN_NAME/$CERT_PFX_FILE`
		if [ $acme_cert_timestamp -ne $sys_pfx_timestamp ];then
# 轉換憑證檔名
			mkdir -p $CERT_DIR/$DOMAIN_NAME
			cd $ACME_DIR
			~/.acme.sh/acme.sh --install-cert -d $DOMAIN_NAME \
					--cert-file      $CERT_DIR/$DOMAIN_NAME/$DOMAIN_NAME.cert  \
					--key-file       $CERT_DIR/$DOMAIN_NAME/$DOMAIN_NAME.key  \
					--fullchain-file $CERT_DIR/$DOMAIN_NAME/$DOMAIN_NAME.chain.crt
			cd $CERT_DIR/$DOMAIN_NAME
			openssl pkcs12 -export -out $CERT_PFX_FILE -inkey $DOMAIN_NAME.key -in $DOMAIN_NAME.cert -certfile $DOMAIN_NAME.chain.crt -password pass:certpasswd
			FILETIME=`date -d @$acme_cert_timestamp +"%Y%m%d%H%M.%S"`
			touch -t $FILETIME $DOMAIN_NAME.cert
			touch -t $FILETIME $DOMAIN_NAME.key
			touch -t $FILETIME $DOMAIN_NAME.chain.crt
			touch -t $FILETIME $CERT_PFX_FILE
			cp $DOMAIN_NAME.chain.crt $GITEA_CERT_DIR
			cp $DOMAIN_NAME.key $GITEA_CERT_DIR
			cd $GITEA_CERT_DIR
			chown $FILE_OWNER:users $DOMAIN_NAME.chain.crt
			chown $FILE_OWNER:users $DOMAIN_NAME.key
			chmod 644 $DOMAIN_NAME.chain.crt
			chmod 644 $DOMAIN_NAME.key
# 將憑證壓縮到下載目錄
			cd $CERT_DIR
			zip $DOMAIN_NAME.zip ./$DOMAIN_NAME/*.*
			mv $DOMAIN_NAME.zip $DOWNLOAD_DIR
			echo $acme_cert_timestamp > $DOWNLOAD_DIR/$DOMAIN_NAME.time
			echo "$(date +"%Y-%m-%d_%H_%M_%S")"  >> $RELOAD_FLAG
		fi
	else
#		echo "No ca file exists at "$ACME_DIR/$DOMAIN_NAME/$CERT_FILE
# 將未成功Domain從清單移除
		cd $ACME_DIR/
		~/.acme.sh/acme.sh --remove -d $DOMAIN_NAME -d \*.$DOMAIN_NAME
		rm -rf ./$DOMAIN_NAME/
	fi
done < $CERT_DOMAIN_LIST

if [ -f "$RELOAD_FLAG" ]; then
# Restart service (haproxy、nginx、gitea、drone)
	cd $DOCKER_ROOT
	docker-compose restart
	rm -f $RELOAD_FLAG
fi


